import sys
import comtypes.test

if __name__ == "__main__":
    sys.exit(comtypes.test.run(sys.argv[1:]))
